-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2019 at 10:08 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `musicquestdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cooperation`
--

CREATE TABLE `cooperation` (
  `IDCoop` int(11) NOT NULL,
  `IDUserOrg` int(11) NOT NULL,
  `IDUserMus` int(11) NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `RatingMusician` float DEFAULT NULL,
  `RatingOrganizer` float DEFAULT NULL,
  `Description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proposalDescription` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `Date` datetime NOT NULL,
  `IDReply` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cooperation`
--

INSERT INTO `cooperation` (`IDCoop`, `IDUserOrg`, `IDUserMus`, `Status`, `RatingMusician`, `RatingOrganizer`, `Description`, `proposalDescription`, `Date`, `IDReply`) VALUES
(1, 16, 1, 'ACCEPTED', NULL, NULL, 'Ariana Grande performing at Sea Dance!', 'Work at seadance?', '2019-10-08 22:22:00', 1),
(2, 16, 4, 'ACCEPTED', NULL, NULL, 'null', 'Work at seadance?', '2019-10-22 12:12:00', 4),
(3, 10, 8, 'REJECTED', NULL, NULL, 'We dont want you to perform!', 'I wanna perform.', '2019-06-07 22:40:00', 10),
(4, 15, 8, 'PENDING', NULL, NULL, NULL, 'I wanna perform.', '2019-08-14 01:01:00', 8),
(5, 11, 5, 'PENDING', NULL, NULL, NULL, 'Can we play?', '2019-06-24 11:11:00', 5),
(6, 16, 5, 'PENDING', NULL, NULL, NULL, 'We wanna play.', '2019-06-28 11:11:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `demovideos`
--

CREATE TABLE `demovideos` (
  `IDUserMus` int(11) NOT NULL,
  `YoutubeLink1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `YoutubeLink2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `YoutubeLink3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `YoutubeLink4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `demovideos`
--

INSERT INTO `demovideos` (`IDUserMus`, `YoutubeLink1`, `YoutubeLink2`, `YoutubeLink3`, `YoutubeLink4`) VALUES
(1, 'https://www.youtube.com/embed/QYh6mYIJG2Y', 'https://www.youtube.com/embed/gl1aHhXnN1k', 'https://www.youtube.com/embed/LH4Y1ZUUx2g', 'https://www.youtube.com/embed/ffxKSjUwKdU'),
(2, 'https://www.youtube.com/embed/JC0MEF6d1eU', 'https://www.youtube.com/embed/DNrK0yhrz0A', 'https://www.youtube.com/embed/NCtzkaL2t_Y', 'https://www.youtube.com/embed/A_MjCqQoLLA'),
(3, 'https://www.youtube.com/embed/xpVfcZ0ZcFM', 'https://www.youtube.com/embed/DRS_PpOrUZ4', 'https://www.youtube.com/embed/uxpDa-c-4Mc', 'https://www.youtube.com/embed/S1gp0m4B5p8'),
(4, 'https://www.youtube.com/embed/8CdcCD5V-d8', 'https://www.youtube.com/embed/XbGs_qK2PQA', 'https://www.youtube.com/embed/_Yhyp-_hX2s', 'https://www.youtube.com/embed/YVkUvmDQ3HY'),
(5, 'https://www.youtube.com/embed/kpznKoohEo0', 'https://www.youtube.com/embed/9Jarx_T-vTI', 'https://www.youtube.com/embed/3rOlFnq6QDI', 'https://www.youtube.com/embed/4Av6UTzLDLk'),
(6, 'https://www.youtube.com/embed/cwQgjq0mCdE', 'https://www.youtube.com/embed/PsO6ZnUZI0g', 'https://www.youtube.com/embed/IxGvm6btP1A', 'https://www.youtube.com/embed/Co0tTeuUVhU'),
(7, 'https://www.youtube.com/embed/AiyetpSHy9s', 'https://www.youtube.com/embed/PfyvV2s6bSc', 'https://www.youtube.com/embed/mbRalXzHSU0', 'https://www.youtube.com/embed/1RYjlFTPFmY'),
(8, 'https://www.youtube.com/embed/9xudyx3ES1U', 'https://www.youtube.com/embed/AuZxccRqB5M', 'https://www.youtube.com/embed/adJgq64POa0', 'https://www.youtube.com/embed/Tbz6xQkewo4'),
(17, NULL, NULL, NULL, NULL),
(19, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `locationpictures`
--

CREATE TABLE `locationpictures` (
  `IDUserOrg` int(11) NOT NULL,
  `pathToPicture1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pathToPicture2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pathToPicture3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pathToPicture4` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `locationpictures`
--

INSERT INTO `locationpictures` (`IDUserOrg`, `pathToPicture1`, `pathToPicture2`, `pathToPicture3`, `pathToPicture4`) VALUES
(9, 'images/9/exit1.jpg', 'images/9/exit3.jpg', 'images/9/exit2.jpg', 'images/9/exit4.jpg'),
(10, 'images/10/reading1.jpg', 'images/10/reading3.png', 'images/10/reading2.jpg', 'images/10/reading4.jpg'),
(11, 'images/11/glastonbury1.jpg', 'images/11/glastonbury3.jpg', 'images/11/glastonbury2.jpg', 'images/11/glastonbury4.jpg'),
(12, 'images/12/wembley1.jpg', 'images/12/wembley3.jpg', 'images/12/wembley2.jpg', 'images/12/wembley4.jpg'),
(13, 'images/13/sziget1.jpg', 'images/13/sziget3.jpeg', 'images/13/sziget2.jpg', 'images/13/sziget4.jpg'),
(14, 'images/14/kolarac1.jpg', 'images/14/kolarac3.jpg', 'images/14/kolarac2.jpg', 'images/14/kolarac4.jpg'),
(15, 'images/15/lovefest1.jpg', 'images/15/lovefest3.jpg', 'images/15/lovefest2.jpg', 'images/15/lovefest4.jpg'),
(16, 'images/16/seadance1.jpg', 'images/16/seadance3.jpg', 'images/16/seadance2.jpg', 'images/16/seadance4.jpg'),
(18, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `musician`
--

CREATE TABLE `musician` (
  `IDUserMus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `musician`
--

INSERT INTO `musician` (`IDUserMus`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(17),
(19);

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `IDUserOrg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`IDUserOrg`) VALUES
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(18);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `IDUser` int(11) NOT NULL,
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Tip` int(11) NOT NULL,
  `TipUser` int(11) NOT NULL,
  `Active` int(11) NOT NULL,
  `ProfilePicture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TotalRating` int(11) DEFAULT NULL,
  `TotalVotes` int(11) DEFAULT NULL,
  `Description` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`IDUser`, `Username`, `Password`, `Name`, `Tip`, `TipUser`, `Active`, `ProfilePicture`, `TotalRating`, `TotalVotes`, `Description`) VALUES
(1, 'arig', 'arig123', 'Ariana Grande', 0, 0, 1, 'images/1/ariana.jpg', NULL, NULL, ''),
(2, 'beatles', 'beatles123', 'Beatles', 0, 0, 1, 'images/2/Beatles-.jpg', NULL, NULL, ''),
(3, 'drake', 'drake123', 'Drake', 0, 0, 1, 'images/3/drake.jpg', NULL, NULL, ''),
(4, 'eminem', 'eminem123', 'Eminem', 0, 0, 1, 'images/4/eminem.jpg', NULL, NULL, ''),
(5, 'eplay', 'eplay123', 'EPlay', 0, 0, 1, 'images/5/eplay.jpg', NULL, NULL, ''),
(6, 'kanye', 'kanye123', 'Kanye West', 0, 0, 1, 'images/6/kanye.png', NULL, NULL, ''),
(7, 'lavan', 'lavan123', 'Lavan', 0, 0, 1, 'images/7/lavan.jpg', NULL, NULL, ''),
(8, 'octavian', 'octavian123', 'Octavian', 0, 0, 1, 'images/8/octavian.jpg', NULL, NULL, ''),
(9, 'exit', 'exit123', 'Exit', 0, 1, 1, 'images/9/exit.jpg', NULL, NULL, ''),
(10, 'reading', 'reading123', 'Reading', 0, 1, 1, 'images/10/reading.jpg', NULL, NULL, ''),
(11, 'glastonbury', 'glastonbury123', 'Glastonbury', 0, 1, 1, 'images/11/glastonbury.jpg', NULL, NULL, ''),
(12, 'wembley', 'wembley123', 'Wembley', 0, 1, 1, 'images/12/wembley.jpg', NULL, NULL, ''),
(13, 'sziget', 'sziget123', 'Sziget', 0, 1, 1, 'images/13/sziget.jpg', NULL, NULL, ''),
(14, 'kolarac', 'kolarac123', 'Kolarac', 0, 1, 1, 'images/14/kolarac.jpg', NULL, NULL, ''),
(15, 'lovefest', 'lovefest123', 'LoveFest', 0, 1, 1, 'images/15/lovefest.jpg', NULL, NULL, ''),
(16, 'seadance', 'seadance123', 'SeaDance', 0, 1, 1, 'images/16/seadance.jpg', NULL, NULL, ''),
(17, 'dusancar11', 'FarmerJoe247', 'DusanCar', 2, 0, 1, 'images/17/Dusan.jpg', NULL, NULL, ''),
(18, 'mickoni17', 'mickomicko', 'Mickoni', 2, 1, 1, 'images/18/Micko.jpg', NULL, NULL, ''),
(19, 'milosj', 'mafeacuprija', 'MilosJ', 1, 0, 1, 'images/19/Milos.jpg', NULL, NULL, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cooperation`
--
ALTER TABLE `cooperation`
  ADD PRIMARY KEY (`IDCoop`),
  ADD KEY `R_9` (`IDUserMus`),
  ADD KEY `R_10` (`IDUserOrg`);

--
-- Indexes for table `demovideos`
--
ALTER TABLE `demovideos`
  ADD PRIMARY KEY (`IDUserMus`);

--
-- Indexes for table `locationpictures`
--
ALTER TABLE `locationpictures`
  ADD PRIMARY KEY (`IDUserOrg`);

--
-- Indexes for table `musician`
--
ALTER TABLE `musician`
  ADD PRIMARY KEY (`IDUserMus`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`IDUserOrg`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`IDUser`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cooperation`
--
ALTER TABLE `cooperation`
  ADD CONSTRAINT `R_10` FOREIGN KEY (`IDUserOrg`) REFERENCES `organizer` (`IDUserOrg`),
  ADD CONSTRAINT `R_9` FOREIGN KEY (`IDUserMus`) REFERENCES `musician` (`IDUserMus`);

--
-- Constraints for table `demovideos`
--
ALTER TABLE `demovideos`
  ADD CONSTRAINT `R_11` FOREIGN KEY (`IDUserMus`) REFERENCES `musician` (`IDUserMus`) ON DELETE CASCADE;

--
-- Constraints for table `locationpictures`
--
ALTER TABLE `locationpictures`
  ADD CONSTRAINT `R_12` FOREIGN KEY (`IDUserOrg`) REFERENCES `organizer` (`IDUserOrg`) ON DELETE CASCADE;

--
-- Constraints for table `musician`
--
ALTER TABLE `musician`
  ADD CONSTRAINT `R_3` FOREIGN KEY (`IDUserMus`) REFERENCES `user` (`IDUser`) ON DELETE CASCADE;

--
-- Constraints for table `organizer`
--
ALTER TABLE `organizer`
  ADD CONSTRAINT `R_4` FOREIGN KEY (`IDUserOrg`) REFERENCES `user` (`IDUser`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
