        <br>
        <div class="row">
            <div class="col-12">
                <p class="HomePageText">MusicQuest is an easy way to connect people. <br> With us opportunities are endless! </p>
            </div>
        </div>
        <!-- Upcoming Events -->
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            
        </div>
<br> <br> <br>

<!-- Slider -->
        <table align="center">
            <tr>
                <td>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-info active">
                            <input type="radio" name="options" id="option1" autocomplete="off" onChange="whichChecked(0)"> Musicians
                        </label>
                        <label class="btn btn-info">
                            <input type="radio" name="options" id="option2" autocomplete="off" onChange="whichChecked(1)"> Locations
                        </label>
                    </div>
                </td>
            </tr>
        </table>

<!-- Slike -->
        <div class="container testimonial-group">
            <div id="rowToFill" class="row text-center">
                
            </div>
        </div>
    </div>
</body>

