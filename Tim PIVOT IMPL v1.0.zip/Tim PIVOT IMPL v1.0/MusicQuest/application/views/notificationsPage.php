<div class="list-group col-lg-8">
      <?php 
        foreach ($resources as $r) {
            echo $r;
        }
      ?>
    </div>
</div>