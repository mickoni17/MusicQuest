<?php

/*Milorad Vulic 0627/2016, Milos Jacimovic 0641/2016
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Organizer
 *
 * @author Windows 10
 */
class Organizer extends CI_Model {
    
    public function __construct() {
        parent::__construct();
    }
}
