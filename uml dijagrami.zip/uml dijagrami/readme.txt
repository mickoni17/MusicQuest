V1.0 - Du�an Nikolic, Milorad Vulic, Milo� Jacimovic
*SSU je radjen u StarUml 3.0 a ostala dva su u starijem zbog toga sto
dodavanje ona dva modula nije bilo moguce u novijem StarUml-u
-Neki slucajevi koriscenja nemaju neuspesan scenario kao na primer "Sign out"
-Radi optimizacije prostora uspesni i neusni scenario su smeseteni u istom
sekvencijalom dijagramu
-Sa obzirom da se vreme predaje za UML i implementaciju razlikuju verorovatne su 
izmene ove verzije dijagrama
-Sta su izmene u narednim verzijama ce biti napisano i ovde 
