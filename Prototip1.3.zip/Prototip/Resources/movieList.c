Americki:
	Apocalypse now
	Magnolia
//	Truman show
	Whiplash
//	Godfather 1,2,3
//	No country for old man
	Scarface
	Once upon a time in america
	The deer hunter
	Dangerous liaisons
	Shine
//	Taxi driver
	The barber of siberia
//	Pulp fiction
//	Inglourious basterds
	Legends of the fall
	Casablanca
	Reservoir dogs
	Eyes wide shut
	2001: A space odyssey
	American beauty
//	The usual suspects
	Lost in translation
	Brokeback mountain
	Birdman
	The big lebowski
	Hollywood boulevard
	Melancholia
	The legend of 1900 (piano)
//	Requiem for a dream
	A clockwork orange
//	Forrest gump
//	Dead poets society
	Scent of a woman
//	Schindlers list
//	Three Billboards Outside Ebbing, Missouri
//	Million dollar baby
	Rebel without a cause
	My left foot
	Kramer vs kramer
	One true thing
	The shining
	Doubt
	Life is beautiful
	Last tango in paris
	
Domaci:
//	Ko to tamo peva
	Otac na sluzbenom putu
	Sjecas li se doli bel
//	Maratonci trce pocasni krug
	Samo jednom se ljubim
	Kad porastem bicu kengur
//	Skupljaci perja
	Lepota poroka
	Nicija zemlja
//	Mi nismo andjeli
//	Kako je propao rokenrol
	
Serije:
	Breaking bad
	True detective
	Monti pajton
	Sopranosi
	Vratice se rode